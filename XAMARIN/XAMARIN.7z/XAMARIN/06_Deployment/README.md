# Deployment in Azure

## Upload in Azure DevOps

In diesem Video wird das Hochladen der Solution in ein Azure DevOps Repository gezeigt. Damit ist
es möglich, dass mehrere Leute in Visual Studio im Projekt zusammenarbeiten können.

**Videolink: https://www.youtube.com/watch?v=Meab4Djw0WE (15m 42s)**

## Erstellen eines App Service in Azure

In diesem Video wird die ASP.NET Core REST API als Azure App Service bereitgestellt. Die App
kann dadurch von überall aus auf die API zugreifen.

**Videolink: https://www.youtube.com/watch?v=rosn8lkf960 (11m 09s)**
