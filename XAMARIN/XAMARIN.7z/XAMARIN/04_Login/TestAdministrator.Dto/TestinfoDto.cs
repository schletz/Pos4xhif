﻿using System;

namespace TestAdministrator.Dto
{
    public class TestinfoDto
    {
        public string Schoolclass { get; set; }
        public string Teacher { get; set; }
        public string Subject { get; set; }
        public DateTime DateFrom { get; set; }
    }
}