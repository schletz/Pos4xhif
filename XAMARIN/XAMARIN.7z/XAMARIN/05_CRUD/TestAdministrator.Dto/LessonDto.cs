﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TestAdministrator.Dto
{
    public class LessonDto
    {
        public string Class { get; set; }
        public string Subject { get; set; }
    }
}
