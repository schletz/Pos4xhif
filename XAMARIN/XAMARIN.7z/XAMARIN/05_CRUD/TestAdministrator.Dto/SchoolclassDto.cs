﻿using System;
using System.Collections.Generic;

namespace TestAdministrator.Dto
{
    public class SchoolclassDto
    {
        public string Id { get; set; }
        public string Department { get; set; }
        public string ClassTeacher { get; set; }
        public int StudentCount { get; set; }
        public IEnumerable<TeacherDto> Teachers { get; set; }
    }
}
