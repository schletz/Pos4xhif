﻿using AspShowcase.Application.Commands;
using AspShowcase.Application.Infrastructure;
using AspShowcase.Application.Models;
using AutoMapper;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;

namespace AspShowcase.Application.Services
{
    public class TaskService
    {
        private readonly AspShowcaseContext _db;
        private readonly IMapper _mapper;
        private readonly IClock _clock;

        public TaskService(AspShowcaseContext db, IMapper mapper, IClock clock)
        {
            _db = db;
            _mapper = mapper;
            _clock = clock;
        }
        public Guid AddTask(NewTaskCmd taskCmd)
        {
            // Wir prüfen, ob es die Fremdschlüsselwerte TeamGUID und TaskGUID überhaupt gibt.
            var team = _db.Teams.FirstOrDefault(t => t.Guid == taskCmd.TeamGuid);
            var teacher = _db.Teachers.FirstOrDefault(t => t.Guid == taskCmd.TeacherGuid);
            if (team is null) { throw new ServiceException("Invalid Team GUID"); }
            if (teacher is null) { throw new ServiceException("Invalid Teacher GUID"); }

            // Der Name des Tasks muss pro Team eindeutig sein. 
            // Wird in der DB geprüft. Wir prüfen, um eine genauere Fehlermeldung geben zu können.
            if (_db.Tasks.Any(t => t.Title == taskCmd.Title && t.Team.Guid == taskCmd.TeamGuid))
                throw new ServiceException($"Task {taskCmd.Title} already exists in Team {team.Name}");
            if (taskCmd.ExpirationDate < _clock.Now)
                throw new ServiceException("Task is expired.");
            // Erzeugt einen Task aus der Cmd Klasse, also TaskCmd --> Task
            // Siehe Mapping Profile: CreateMap<TaskCmd, Task>()
            var task = _mapper.Map<Task>(taskCmd, opt =>
            {
                opt.AfterMap((src, dest) =>
                {
                    dest.Team = team;
                    dest.Teacher = teacher;
                });
            });

            _db.Tasks.Add(task);
            try { _db.SaveChanges(); }
            catch (DbUpdateException e) { throw new ServiceException(e.InnerException?.Message ?? e.Message); }
            return task.Guid;
        }
        public void EditTask(EditTaskCmd taskCmd)
        {
            // Suche den alten Task in der Datenbank
            var task = _db.Tasks.FirstOrDefault(t => t.Guid == taskCmd.Guid);
            if (task is null) { throw new ServiceException($"Task {taskCmd.Guid} does not exist."); }
            if (task.ExpirationDate < _clock.Now)
                throw new ServiceException($"Task is expired.");
            if (_db.Handins.Any(h => h.Task.Id == task.Id))
                throw new ServiceException($"Cannot change task because there are existing handins.");


            // Map(source, dest) aktualisiert das dest Objekt mit den Daten von source.
            _mapper.Map(taskCmd, task);

            try { _db.SaveChanges(); }
            catch (DbUpdateException e) { throw new ServiceException(e.InnerException?.Message ?? e.Message); }
        }
        public void DeleteTask(Guid guid, bool force)
        {
            var task = _db.Tasks.FirstOrDefault(t => t.Guid == guid);
            if (task is null)
                throw new ServiceException($"Task {guid} not found") { NotFound = true };

            if (_db.Handins.Any(h => h.Task.Id == task.Id))
            {
                if (!force)
                {
                    throw new ServiceException($"Cannot delete task because there are existing handins.")
                    { Forbidden = true };
                };
                // Alle Handins löschen, denn sonst kann die DB den Task nicht löschen
                // (Foreign Key Problem)
                var handins = _db.Handins.Where(h => h.Task.Id == task.Id).ToList();
                _db.Handins.RemoveRange(handins);
                try { _db.SaveChanges(); }
                catch (DbUpdateException e)
                { throw new ServiceException(e.InnerException?.Message ?? e.Message); }
            }
            _db.Tasks.Remove(task);
            try { _db.SaveChanges(); }
            catch (DbUpdateException e)
            { throw new ServiceException(e.InnerException?.Message ?? e.Message); }
        }
    }
}
