﻿using System;
using System.ComponentModel.DataAnnotations;

namespace AspShowcase.Application.Commands
{
    public record NewTaskCmd(
        [StringLength(16, MinimumLength = 1, ErrorMessage = "Ungültiges Subject")] string Subject,
        [StringLength(255, MinimumLength = 1, ErrorMessage = "Ungültiger Title")] string Title,
        Guid TeamGuid,
        Guid TeacherGuid,
        DateTime ExpirationDate,
        [Range(1, 999, ErrorMessage = "Ungültige maximale Punkteanzahl")] int? MaxPoints);
}