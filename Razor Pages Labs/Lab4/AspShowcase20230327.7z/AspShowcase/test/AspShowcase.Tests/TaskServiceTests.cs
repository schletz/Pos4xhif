﻿using AspShowcase.Application.Commands;
using AspShowcase.Application.Infrastructure;
using AspShowcase.Application.Models;
using AspShowcase.Application.Services;
using System;
using System.Linq;

namespace AspShowcase.Tests
{
    public class TaskServiceTests : DatabaseTest
    {
        private AspShowcaseContext GenerateDbFixtures()
        {
            var db = GetConnection(createDb: true);
            var teacher = new Teacher(
                firstname: "Firstname",
                lastname: "Lastname", email: "email@spengergasse.at");
            var team = new Team(
                name: "Testteam", schoolclass: "6BKIF");
            db.Teachers.Add(teacher);
            db.Teams.Add(team);
            db.SaveChanges();
            var task = new Task(
                subject: "POS", title: "New Task", team: team, teacher: teacher,
                expirationDate: new DateTime(2024, 1, 1), maxPoints: 16);
            db.Tasks.Add(task);
            db.SaveChanges();
            db.ChangeTracker.Clear();
            return db;
        }
        [Fact]
        public void AddTaskSuccessTest()
        {
            // ARRANGE
            var db = GenerateDbFixtures();
            var mapper = GetMapper();
            var clock = new FakeClock(new DateTime(2023, 1, 1));
            var service = new TaskService(db, mapper, clock);

            // ACT
            var team = db.Teams.First();
            var teacher = db.Teachers.First();
            var cmd = new NewTaskCmd(Subject: "POS", Title: "New Task 2",
                TeamGuid: team.Guid, TeacherGuid: teacher.Guid,
                new DateTime(2023, 3, 22), MaxPoints: 16);
            var guid = service.AddTask(cmd);

            // ASSERT
            db.ChangeTracker.Clear();
            Assert.True(db.Tasks.Any(t => t.Guid == guid));
        }

        [Fact]
        public void AddTaskThrowsServiceExceptionIfExpiredTest()
        {
            // ARRANGE
            var db = GenerateDbFixtures();
            var mapper = GetMapper();
            var clock = new FakeClock(new DateTime(2023, 1, 1));
            var service = new TaskService(db, mapper, clock);

            // ACT
            var team = db.Teams.First();
            var teacher = db.Teachers.First();
            var cmd = new NewTaskCmd(Subject: "POS", Title: "New Task 2",
                TeamGuid: team.Guid, TeacherGuid: teacher.Guid,
                new DateTime(2022, 1, 1), MaxPoints: 16);

            // ACT/ASSERT
            db.ChangeTracker.Clear();
            var e = Assert.Throws<ServiceException>(() => service.AddTask(cmd));
            Assert.Contains("Task is expired", e.Message);
        }

        [Fact]
        public void AddTaskThrowsServiceExceptionIfTeamIsInvalidTest()
        {
            // ARRANGE
            var db = GenerateDbFixtures();
            var mapper = GetMapper();
            var clock = new FakeClock(new DateTime(2023, 1, 1));
            var service = new TaskService(db, mapper, clock);
            // ACT
            var teacher = db.Teachers.First();
            var cmd = new NewTaskCmd(Subject: "POS", Title: "New Task 2",
                TeamGuid: Guid.Empty, TeacherGuid: teacher.Guid,
                new DateTime(2024, 1, 1), MaxPoints: 16);
            // ACT/ASSERT
            db.ChangeTracker.Clear();
            var e = Assert.Throws<ServiceException>(() => service.AddTask(cmd));
            Assert.Contains("Invalid Team GUID", e.Message);
        }
        [Fact]
        public void AddTaskThrowsServiceExceptionIfTeacherIsInvalidTest()
        {
            // ARRANGE
            var db = GenerateDbFixtures();
            var mapper = GetMapper();
            var clock = new FakeClock(new DateTime(2023, 1, 1));
            var service = new TaskService(db, mapper, clock);
            // ACT
            var team = db.Teams.First();
            var cmd = new NewTaskCmd(Subject: "POS", Title: "New Task 2",
                TeamGuid: team.Guid, TeacherGuid: Guid.Empty,
                new DateTime(2024, 1, 1), MaxPoints: 16);
            // ACT/ASSERT
            db.ChangeTracker.Clear();
            var e = Assert.Throws<ServiceException>(() => service.AddTask(cmd));
            Assert.Contains("Invalid Teacher GUID", e.Message);
        }
        [Fact]
        public void AddTaskThrowsServiceExceptionIfTitleAlreadyExistsTest()
        {
            // ARRANGE
            var db = GenerateDbFixtures();
            var teacher = db.Teachers.First();
            var team = db.Teams.First();
            var mapper = GetMapper();
            var clock = new FakeClock(new DateTime(2023, 1, 1));
            var service = new TaskService(db, mapper, clock);
            var cmd = new NewTaskCmd(Subject: "POS", Title: "New Task",
                TeamGuid: team.Guid, TeacherGuid: teacher.Guid,
                new DateTime(2024, 1, 1), MaxPoints: 16);
            
            db.ChangeTracker.Clear();
            var e = Assert.Throws<ServiceException>(() => service.AddTask(cmd));
            Assert.Contains("already exists in Team", e.Message);
        }
    }
}
