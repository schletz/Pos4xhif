﻿using System;

namespace AspShowcase.Application.Services
{
    public class ClockService : IClock
    {
        public DateTime Now => DateTime.Now;
        public DateTime UtcNow => DateTime.UtcNow;
    }
}
