using AspShowcase.Application.Infrastructure;
using AspShowcase.Application.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Collections.Generic;
using System.Linq;

namespace AspShowcase.Webapp.Pages.Students
{
    public class IndexModel : PageModel
    {
        private readonly AspShowcaseContext _db;

        public IndexModel(AspShowcaseContext db)
        {
            _db = db;
        }

        public List<Student> Students { get; private set; } = new();
        // Page handler f�r GET /students
        public void OnGet()
        {
            Students = _db.Students
                .OrderBy(s => s.Lastname)
                .ToList();
        }
    }
}
