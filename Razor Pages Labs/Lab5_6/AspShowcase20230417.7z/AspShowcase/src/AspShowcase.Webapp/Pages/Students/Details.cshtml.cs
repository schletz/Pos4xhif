using AspShowcase.Application.Infrastructure;
using AspShowcase.Application.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Collections.Generic;
using System.Linq;

namespace AspShowcase.Webapp.Pages.Students
{
    public class DetailsModel : PageModel
    {
        public record StudentWithHandinsDto(
            string Firstname, string Lastname, string Email,
            List<HandinDto> Handins);
        public record HandinDto(
            DateTime Created, string Description,
            string DocumentUrl, string TaskTitle, bool Expired,
            TimeSpan ExpiresIn);

        private readonly AspShowcaseContext _db;

        public DetailsModel(AspShowcaseContext db)
        {
            _db = db;
        }

        [FromRoute]
        public Guid Guid { get; set; }
        public StudentWithHandinsDto Student { get; private set; } = default!;
        public IActionResult OnGet()
        {
            // SELECT * FROM Students WHERE ...
            // var student = _db.Students.FirstOrDefault(s => s.Guid == Guid);
            // Besser mit DTO Klassen die Daten definieren, die wir f�r das Rendern
            // der Page brauchen.
            var student = _db.Students
                .Where(s => s.Guid == Guid)
                .Select(s => new StudentWithHandinsDto(
                    s.Firstname, s.Lastname, s.Email,
                    s.Handins
                        .Select(h => new HandinDto(
                            h.Created, h.Description, h.DocumentUrl,
                            h.Task.Title, h.Task.ExpirationDate < DateTime.UtcNow,
                            h.Task.ExpirationDate - DateTime.UtcNow))
                        .ToList()))
                .FirstOrDefault();
            if (student is null) { return NotFound(); }
            Student = student;
            return Page();
        }
    }
}
