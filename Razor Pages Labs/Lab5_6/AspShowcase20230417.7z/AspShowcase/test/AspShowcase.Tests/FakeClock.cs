﻿using AspShowcase.Application.Services;
using System;

namespace AspShowcase.Tests
{
    public class FakeClock : IClock
    {
        private readonly DateTime _dateTime;
        public FakeClock(DateTime dateTime)
        {
            _dateTime = dateTime;
        }
        public DateTime Now => _dateTime;
        public DateTime UtcNow => _dateTime;
    }
}
