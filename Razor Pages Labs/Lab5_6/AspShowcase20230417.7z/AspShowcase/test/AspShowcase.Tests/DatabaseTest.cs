﻿using AspShowcase.Application.Dtos;
using AspShowcase.Application.Infrastructure;
using AspShowcase.Application.Models;
using AutoMapper;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;

namespace AspShowcase.Tests
{
    public class DatabaseTest
    {
        public AspShowcaseContext GetConnection(bool createDb = false)
        {
            var connection = new SqliteConnection("DataSource=:memory:");
            connection.Open();
            var opt = new DbContextOptionsBuilder()
                .UseSqlite(connection)
                .Options;
            var db = new AspShowcaseContext(opt);
            if (createDb)
            {
                db.Database.EnsureDeleted();
                db.Database.EnsureCreated();
            }
            return db;
        }

        public IMapper GetMapper()
        {
            var configuration = new MapperConfiguration(cfg => cfg.AddMaps(typeof(MappingProfile)));
            return new Mapper(configuration);
        }
    }
}
